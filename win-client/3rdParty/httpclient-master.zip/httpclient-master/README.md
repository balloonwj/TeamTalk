httpclient
==========

Http client for windows 

* [构造HttpClient三部曲之一：支持代理的Socket封装][1]
* [构造HttpClient三部曲之二：GET方法实现][2]
* [构造HttpClient三部曲之三：POST方法实现][3]


[1]:http://xiangwangfeng.com/2011/05/08/%E6%9E%84%E9%80%A0HttpClient%E4%B8%89%E9%83%A8%E6%9B%B2%E4%B9%8B%E4%B8%80%EF%BC%9A%E6%94%AF%E6%8C%81%E4%BB%A3%E7%90%86%E7%9A%84Socket%E5%B0%81%E8%A3%85/
[2]:http://xiangwangfeng.com/2011/05/09/%E6%9E%84%E9%80%A0HttpClient%E4%B8%89%E9%83%A8%E6%9B%B2%E4%B9%8B%E4%BA%8C%EF%BC%9AGET%E6%96%B9%E6%B3%95%E5%AE%9E%E7%8E%B0/
[3]:http://xiangwangfeng.com/2011/05/15/%E6%9E%84%E9%80%A0HttpClient%E4%B8%89%E9%83%A8%E6%9B%B2%E4%B9%8B%E4%B8%89%EF%BC%9APOST%E6%96%B9%E6%B3%95%E5%AE%9E%E7%8E%B0/
