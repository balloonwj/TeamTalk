﻿/**
 * @file    http_response.cpp
 * @brief   Http反馈
 * @author  xiangwangfeng <xiangwangfeng@gmail.com>
 * @data	2011-4-24
 * @website www.xiangwangfeng.com
 */

#include "standard_header.h"
#include "http_response.h"

NAMESPACE_BEGIN(Http)

//空...

NAMESPACE_END(Http)